# حزمة تبعيات OpenCode لـ ARM64

تحتوي هذه الحزمة على **التغيير المعلّق فقط** لإضافة تبعيات `proot` و`libtalloc` المضمّنة إلى تطبيق CodeOnTheGo وتثبيتها من داخل التطبيق. الهدف هو المستودع `bala554/CodeOnTheGo` والفرع `feature/opencode-runtime`.

تضم الحزمة 9 ملفات مشروع مع الحفاظ على مساراتها النسبية، إضافةً إلى ملف README هذا. لا تنسخ هذا الـ README إلى جذر المستودع؛ استخدمه كدليل دمج فقط. لم يُضمّن محتوى التغييرات التاريخية الموجودة مسبقًا في الفرع.

## الملفات المضمّنة

- `app/build.gradle.kts`
- `app/src/main/java/com/itsaky/androidide/actions/editor/OpenCodeRuntimeController.kt`
- `app/src/main/java/com/itsaky/androidide/actions/editor/OpenCodeRuntimeDialog.kt`
- `app/src/main/java/com/itsaky/androidide/actions/editor/OpenCodeRuntimeInstaller.kt`
- `app/src/main/java/com/itsaky/androidide/actions/editor/OpenCodeBundledDependenciesInstaller.kt`
- `app/src/test/java/com/itsaky/androidide/actions/editor/OpenCodeRuntimeInstallerTest.kt`
- `app/src/main/assets/opencode-runtime/arm64/proot_5.1.107-70_aarch64.deb`
- `app/src/main/assets/opencode-runtime/arm64/libtalloc_2.4.3_aarch64.deb`
- `resources/src/main/res/values/opencode.xml`

حزم DEB مخصّصة لـ ARM64 ومثبتة التحقق ببصمات SHA-256 داخل المثبّت:

- `proot_5.1.107-70_aarch64.deb` — `29b3c942ce36549771d189cdac6edee14ba4636a187afc6d6482eb6b063d8a92`
- `libtalloc_2.4.3_aarch64.deb` — `4857a7faab1a179804e07fa9538e8c026387c1b6a05d0bb7bc8deb755eaded8b`

حزمة `libtalloc-static` غير مطلوبة لهذا التغيير.

## خطوات إضافة الملفات إلى الفرع

1. افتح نسخة العمل الخاصة بمستودع `bala554/CodeOnTheGo`. قبل المتابعة، احفظ أي تعديلات شخصية وتأكد من عدم استبدال تغييرات أخرى غير محفوظة.

2. انتقل إلى الفرع المطلوب. إذا كان الفرع موجودًا محليًا:

   ```bash
   git switch feature/opencode-runtime
   ```

   وإذا لم يكن موجودًا محليًا لكنه موجود على `origin`:

   ```bash
   git fetch origin
   git switch --track -c feature/opencode-runtime origin/feature/opencode-runtime
   ```

3. فك ضغط ملف ZIP في مجلد مؤقت. سيظهر مجلد باسم `opencode-arm64-runtime-delta`.

4. ادمج مجلدي `app` و`resources` من الحزمة في جذر نسخة المستودع، مع الحفاظ على المسارات. مثال على Linux/macOS:

   ```bash
   PACKAGE=/path/to/opencode-arm64-runtime-delta
   REPO=/path/to/CodeOnTheGo
   cp -a "$PACKAGE/app/." "$REPO/"
   cp -a "$PACKAGE/resources/." "$REPO/"
   ```

   استبدل `/path/to/...` بالمسارات الفعلية. عند استخدام مدير الملفات، انسخ محتويات مجلدي `app` و`resources` إلى جذر نسخة المستودع ووافق على دمج المجلدات واستبدال الملفات التسعة المذكورة أعلاه فقط. لا تنسخ مجلد الحزمة نفسه أو ملف `README.md` الخاص بها إلى جذر المشروع.

5. راجع التغييرات وتأكد من أن الفرع صحيح:

   ```bash
   cd /path/to/CodeOnTheGo
   git branch --show-current
   git status --short
   git diff --check
   git diff -- app/build.gradle.kts app/src/main/java/com/itsaky/androidide/actions/editor/OpenCodeRuntimeController.kt app/src/main/java/com/itsaky/androidide/actions/editor/OpenCodeRuntimeDialog.kt app/src/main/java/com/itsaky/androidide/actions/editor/OpenCodeRuntimeInstaller.kt app/src/test/java/com/itsaky/androidide/actions/editor/OpenCodeRuntimeInstallerTest.kt resources/src/main/res/values/opencode.xml
   ```

   تأكد أن اسم الفرع هو `feature/opencode-runtime` وأن الملفات المعروضة تخص هذا التغيير فقط.

6. شغّل اختبار المثبّت المستهدف (يتطلب إعداد Android SDK وGradle للمشروع):

   ```bash
   ./gradlew :app:testDebugUnitTest --tests 'com.itsaky.androidide.actions.editor.OpenCodeRuntimeInstallerTest'
   ```

7. أضف ملفات التغيير التسعة إلى الالتزام، ثم أنشئه:

   ```bash
   git add \
     app/build.gradle.kts \
     app/src/main/java/com/itsaky/androidide/actions/editor/OpenCodeRuntimeController.kt \
     app/src/main/java/com/itsaky/androidide/actions/editor/OpenCodeRuntimeDialog.kt \
     app/src/main/java/com/itsaky/androidide/actions/editor/OpenCodeRuntimeInstaller.kt \
     app/src/main/java/com/itsaky/androidide/actions/editor/OpenCodeBundledDependenciesInstaller.kt \
     app/src/test/java/com/itsaky/androidide/actions/editor/OpenCodeRuntimeInstallerTest.kt \
     app/src/main/assets/opencode-runtime/arm64/proot_5.1.107-70_aarch64.deb \
     app/src/main/assets/opencode-runtime/arm64/libtalloc_2.4.3_aarch64.deb \
     resources/src/main/res/values/opencode.xml
   git diff --cached --check
   git commit -m "Bundle ARM64 OpenCode runtime dependencies"
   ```

8. بعد التأكد من الالتزام والفرع، ارفع التغييرات يدويًا إلى المستودع البعيد:

   ```bash
   git push origin feature/opencode-runtime
   ```

لم يتم تنفيذ أي التزام أو رفع أو نشر أثناء إعداد هذه الحزمة.
